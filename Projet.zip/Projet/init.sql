CREATE TABLE votes (
    id SERIAL PRIMARY KEY,
    vote_option VARCHAR(50) NOT NULL
);
